import { useState, useEffect } from 'react';
import { LivesData, RxData } from '../types';
import { fetchInitialData } from '../services/dataService';

interface InitialDataState {
  initialLivesData: LivesData[];
  initialRxData: RxData[];
  initialZincData: RxData[];
  initialEmisarData: RxData[];
  initialAscentData: RxData[];
  error: Error | null;
  loading: boolean;
}

export const useInitialData = () => {
  const [state, setState] = useState<InitialDataState>({
    initialLivesData: [],
    initialRxData: [],
    initialZincData: [],
    initialEmisarData: [],
    initialAscentData: [],
    error: null,
    loading: true
  });

  useEffect(() => {
    const loadData = async () => {
      try {
        setState(prev => ({ ...prev, loading: true, error: null }));
        const fetchedData = await fetchInitialData();
        
        setState({
          initialLivesData: fetchedData.livesData,
          initialRxData: fetchedData.rxData,
          initialZincData: fetchedData.zincData,
          initialEmisarData: fetchedData.emisarData,
          initialAscentData: fetchedData.ascentData,
          error: null,
          loading: false
        });
      } catch (error) {
        setState(prev => ({
          ...prev,
          error: error instanceof Error ? error : new Error('Failed to load data'),
          loading: false
        }));
      }
    };

    loadData();
  }, []);

  return state;
};