import { LivesData, RxData } from '../types';

export interface DataResponse {
  livesData: LivesData[];
  rxData: RxData[];
  zincData: RxData[];
  emisarData: RxData[];
  ascentData: RxData[];
}

const marketData: DataResponse = {
  "rxData": [
    {
      "date": "Aug 23",
      "xywavTRxVolume": 6228,
      "lumryzTRxVolume": 173,
      "sodOxybateTRxVolume": 1955,
      "xyremTRxVolume": 1814,
      "xywavTRxShare": 61.23893805309735,
      "lumryzTRxShare": 1.7010816125860373,
      "sodOxybateTRxShare": 19.22320550639135,
      "xyremTRxShare": 17.836774827925268,
      "xywavNBRxVolume": 686,
      "lumryzNBRxVolume": 103,
      "sodOxybateNBRxVolume": 238,
      "xyremNBRxVolume": 151,
      "xywavNBRxShare": 58.23429541595926,
      "lumryzNBRxShare": 8.743633276740239,
      "sodOxybateNBRxShare": 20.203735144312393,
      "xyremNBRxShare": 12.818336162988114
    },
    // ... rest of rxData array
  ],
  "livesData": [
    {
      "month": "M00",
      "wakixCommercial": 0.1,
      "xywavCommercial": 0,
      "lumryzCommercial": 0,
      "wakixMedicare": 0.1,
      "xywavMedicare": null,
      "lumryzMedicare": null
    },
    // ... rest of livesData array
  ],
  "zincData": [
    {
      "date": " Aug 23",
      "xywavTRxVolume": 1964,
      "lumryzTRxVolume": 69,
      "sodOxybateTRxVolume": 522,
      "xyremTRxVolume": 754,
      "xywavTRxShare": 59.35327893623451,
      "lumryzTRxShare": 2.085222121486854,
      "sodOxybateTRxShare": 15.775158658204896,
      "xyremTRxShare": 22.786340284073738,
      "xywavNBRxVolume": 157,
      "lumryzNBRxVolume": 36,
      "sodOxybateNBRxVolume": 44,
      "xyremNBRxVolume": 52,
      "xywavNBRxShare": 54.325259515570934,
      "lumryzNBRxShare": 12.45674740484429,
      "sodOxybateNBRxShare": 15.22491349480969,
      "xyremNBRxShare": 17.99307958477509,
      "undefinedTRxVolume": 100
    },
    // ... rest of zincData array
  ],
  "emisarData": [
    {
      "date": " Aug 23",
      "xywavTRxVolume": 1273,
      "lumryzTRxVolume": 28,
      "sodOxybateTRxVolume": 337,
      "xyremTRxVolume": 376,
      "xywavTRxShare": 63.20754716981132,
      "lumryzTRxShare": 1.3902681231380336,
      "sodOxybateTRxShare": 16.73286991062562,
      "xyremTRxShare": 18.669314796425024,
      "xywavNBRxVolume": 55,
      "lumryzNBRxVolume": 10,
      "sodOxybateNBRxVolume": 17,
      "xyremNBRxVolume": 8,
      "xywavNBRxShare": 61.111111111111114,
      "lumryzNBRxShare": 11.11111111111111,
      "sodOxybateNBRxShare": 18.88888888888889,
      "xyremNBRxShare": 8.88888888888889
    },
    // ... rest of emisarData array
  ],
  "ascentData": [
    {
      "date": " Aug 23",
      "xywavTRxVolume": 2991,
      "lumryzTRxVolume": 76,
      "sodOxybateTRxVolume": 1096,
      "xyremTRxVolume": 684,
      "xywavTRxShare": 61.70827315865483,
      "lumryzTRxShare": 1.5679801939343925,
      "sodOxybateTRxShare": 22.61192490200124,
      "xyremTRxShare": 14.11182174540953,
      "xywavNBRxVolume": 474,
      "lumryzNBRxVolume": 57,
      "sodOxybateNBRxVolume": 177,
      "xyremNBRxVolume": 91,
      "xywavNBRxShare": 59.32415519399249,
      "lumryzNBRxShare": 7.133917396745932,
      "sodOxybateNBRxShare": 22.152690863579476,
      "xyremNBRxShare": 11.389236545682103
    },
    // ... rest of ascentData array
  ]
};

const validateData = (data: any): data is DataResponse => {
  if (!data || typeof data !== 'object') return false;
  
  const hasArrayProperty = (prop: keyof DataResponse) => 
    Array.isArray(data[prop]) && data[prop].length > 0;

  return (
    hasArrayProperty('livesData') &&
    hasArrayProperty('rxData') &&
    hasArrayProperty('zincData') &&
    hasArrayProperty('emisarData') &&
    hasArrayProperty('ascentData')
  );
};

export const fetchInitialData = async (): Promise<DataResponse> => {
  try {
    if (!validateData(marketData)) {
      throw new Error('Invalid data format in market data');
    }
    
    return marketData;
  } catch (error) {
    console.error('Error loading data:', error);
    throw error;
  }
};