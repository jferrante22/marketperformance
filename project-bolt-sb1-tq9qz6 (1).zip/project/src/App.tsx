import React from 'react';
import { Tab, Tabs, TabList, TabPanel } from 'react-tabs';
import { useLocalStorage } from './hooks/useLocalStorage';
import { useInitialData } from './hooks/useInitialData';
import { LivesData, RxData } from './types';
import { CoverageOverview } from './components/coverage/CoverageOverview';
import { CoverageChart } from './components/CoverageChart';
import { MarketComparisonChart } from './components/MarketAnalysisChart';
import { RxChart } from './components/RxChart';
import { GPOPerformance } from './components/GPOPerformance';
import { LivesDataTable } from './components/LivesDataTable';
import { RxDataManagement } from './components/RxDataManagement';
import { GPODataManagement } from './components/GPODataManagement';
import { DataManagement } from './components/DataManagement';
import { LoadingSpinner } from './components/ui/LoadingSpinner';
import { ErrorMessage } from './components/ui/ErrorMessage';

function App() {
  const { 
    initialLivesData, 
    initialRxData, 
    initialZincData, 
    initialEmisarData, 
    initialAscentData,
    error,
    loading
  } = useInitialData();

  const [livesData, setLivesData] = useLocalStorage<LivesData[]>('livesData', initialLivesData);
  const [rxData, setRxData] = useLocalStorage<RxData[]>('rxData', initialRxData);
  const [zincData, setZincData] = useLocalStorage<RxData[]>('zincData', initialZincData);
  const [emisarData, setEmisarData] = useLocalStorage<RxData[]>('emisarData', initialEmisarData);
  const [ascentData, setAscentData] = useLocalStorage<RxData[]>('ascentData', initialAscentData);

  if (loading) {
    return <LoadingSpinner />;
  }

  if (error) {
    return <ErrorMessage error={error} />;
  }

  return (
    <div className="min-h-screen bg-[#1e1e1e] p-6">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-3xl font-bold mb-8 text-white">Lumryz Market Performance Dashboard</h1>
        
        <DataManagement 
          rxData={rxData}
          livesData={livesData}
          zincData={zincData}
          emisarData={emisarData}
          ascentData={ascentData}
          onRxDataChange={setRxData}
          onLivesDataChange={setLivesData}
          onZincDataChange={setZincData}
          onEmisarDataChange={setEmisarData}
          onAscentDataChange={setAscentData}
        />
        
        <Tabs>
          <TabList>
            <Tab>Coverage Data</Tab>
            <Tab>Market Performance</Tab>
            <Tab>GPO Performance</Tab>
            <Tab>Data Management</Tab>
          </TabList>

          <TabPanel>
            <div className="space-y-8">
              <CoverageOverview data={livesData} />
              <div className="bg-[#171717] p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-6 text-white">Commercial Lives Covered by Month Post Launch</h2>
                <CoverageChart data={livesData} type="commercial" />
              </div>
            </div>
          </TabPanel>

          <TabPanel>
            <div className="space-y-8">
              <div className="bg-[#171717] p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-6 text-white">Market Share Comparison</h2>
                <MarketComparisonChart data={rxData} type="TRx" />
              </div>
              <div className="bg-[#171717] p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-6 text-white">Lumryz TRx Analysis</h2>
                <RxChart data={rxData} type="TRx" product="lumryz" />
              </div>
              <div className="bg-[#171717] p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-6 text-white">Lumryz NBRx Analysis</h2>
                <RxChart data={rxData} type="NBRx" product="lumryz" />
              </div>
            </div>
          </TabPanel>

          <TabPanel>
            <div className="space-y-8">
              <GPOPerformance 
                data={zincData} 
                title="Zinc Performance"
                product="xywav"
              />
              <GPOPerformance 
                data={emisarData}
                title="Emisar Performance"
                product="sodOxybate"
              />
              <GPOPerformance 
                data={ascentData}
                title="Ascent Performance"
                product="xyrem"
              />
            </div>
          </TabPanel>

          <TabPanel>
            <div className="space-y-8">
              <div className="bg-[#171717] p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-6 text-white">Coverage Data</h2>
                <LivesDataTable data={livesData} onDataChange={setLivesData} />
              </div>
              <div className="bg-[#171717] p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-6 text-white">Rx Data Management</h2>
                <RxDataManagement data={rxData} onDataChange={setRxData} />
              </div>
              <div className="bg-[#171717] p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-6 text-white">Zinc Data Management</h2>
                <GPODataManagement 
                  initialData={zincData}
                  gpoName="zinc"
                  onDataChange={setZincData}
                />
              </div>
              <div className="bg-[#171717] p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-6 text-white">Emisar Data Management</h2>
                <GPODataManagement 
                  initialData={emisarData}
                  gpoName="emisar"
                  onDataChange={setEmisarData}
                />
              </div>
              <div className="bg-[#171717] p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-6 text-white">Ascent Data Management</h2>
                <GPODataManagement 
                  initialData={ascentData}
                  gpoName="ascent"
                  onDataChange={setAscentData}
                />
              </div>
            </div>
          </TabPanel>
        </Tabs>
      </div>
    </div>
  );
}

export default App;