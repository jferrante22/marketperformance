export interface RxData {
  date: string;
  xywavTRxVolume: number | null;
  lumryzTRxVolume: number | null;
  sodOxybateTRxVolume: number | null;
  xyremTRxVolume: number | null;
  xywavTRxShare: number | null;
  lumryzTRxShare: number | null;
  sodOxybateTRxShare: number | null;
  xyremTRxShare: number | null;
  xywavNBRxVolume: number | null;
  lumryzNBRxVolume: number | null;
  sodOxybateNBRxVolume: number | null;
  xyremNBRxVolume: number | null;
  xywavNBRxShare: number | null;
  lumryzNBRxShare: number | null;
  sodOxybateNBRxShare: number | null;
  xyremNBRxShare: number | null;
}