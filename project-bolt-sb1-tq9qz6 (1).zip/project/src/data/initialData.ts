import { LivesData, RxData } from '../types';

export const initialLivesData: LivesData[] = [
  {
    month: 'M00',
    wakixCommercial: 0.1,
    xywavCommercial: 0.0,
    lumryzCommercial: 0.0,
    wakixMedicare: 0.1,
    xywavMedicare: 0.0,
    lumryzMedicare: 0.0
  },
  {
    month: 'M01',
    wakixCommercial: 0.1,
    xywavCommercial: 0.0,
    lumryzCommercial: 0.0,
    wakixMedicare: 0.1,
    xywavMedicare: 0.0,
    lumryzMedicare: 0.0
  },
  {
    month: 'M02',
    wakixCommercial: 8.3,
    xywavCommercial: 0.0,
    lumryzCommercial: 29.0,
    wakixMedicare: 8.3,
    xywavMedicare: 0.0,
    lumryzMedicare: 29.0
  }
];

export const initialRxData: RxData[] = [
  {
    date: 'Aug 23',
    xywavTRxVolume: 4104,
    lumryzTRxVolume: 2,
    sodOxybateTRxVolume: 1158,
    xyremTRxVolume: 1439,
    xywavTRxShare: 59.4,
    lumryzTRxShare: 2.1,
    sodOxybateTRxShare: 15.8,
    xyremTRxShare: 22.8,
    xywavNBRxVolume: 0,
    lumryzNBRxVolume: 0,
    sodOxybateNBRxVolume: 0,
    xyremNBRxVolume: 0,
    xywavNBRxShare: 0,
    lumryzNBRxShare: 0,
    sodOxybateNBRxShare: 0,
    xyremNBRxShare: 0
  }
];

export const initialZincData: RxData[] = [
  {
    date: 'Aug 23',
    xywavTRxVolume: 1964,
    lumryzTRxVolume: 69,
    sodOxybateTRxVolume: 522,
    xyremTRxVolume: 754,
    xywavTRxShare: 59.4,
    lumryzTRxShare: 2.1,
    sodOxybateTRxShare: 15.8,
    xyremTRxShare: 22.8,
    xywavNBRxVolume: 0,
    lumryzNBRxVolume: 0,
    sodOxybateNBRxVolume: 0,
    xyremNBRxVolume: 0,
    xywavNBRxShare: 0,
    lumryzNBRxShare: 0,
    sodOxybateNBRxShare: 0,
    xyremNBRxShare: 0
  }
];

export const initialEmisarData: RxData[] = [
  {
    date: 'Aug 23',
    xywavTRxVolume: 1964,
    lumryzTRxVolume: 69,
    sodOxybateTRxVolume: 522,
    xyremTRxVolume: 754,
    xywavTRxShare: 59.4,
    lumryzTRxShare: 2.1,
    sodOxybateTRxShare: 15.8,
    xyremTRxShare: 22.8,
    xywavNBRxVolume: 0,
    lumryzNBRxVolume: 0,
    sodOxybateNBRxVolume: 0,
    xyremNBRxVolume: 0,
    xywavNBRxShare: 0,
    lumryzNBRxShare: 0,
    sodOxybateNBRxShare: 0,
    xyremNBRxShare: 0
  }
];

export const initialAscentData: RxData[] = [
  {
    date: 'Aug 23',
    xywavTRxVolume: 1964,
    lumryzTRxVolume: 69,
    sodOxybateTRxVolume: 522,
    xyremTRxVolume: 754,
    xywavTRxShare: 59.4,
    lumryzTRxShare: 2.1,
    sodOxybateTRxShare: 15.8,
    xyremTRxShare: 22.8,
    xywavNBRxVolume: 0,
    lumryzNBRxVolume: 0,
    sodOxybateNBRxVolume: 0,
    xyremNBRxVolume: 0,
    xywavNBRxShare: 0,
    lumryzNBRxShare: 0,
    sodOxybateNBRxShare: 0,
    xyremNBRxShare: 0
  }
];