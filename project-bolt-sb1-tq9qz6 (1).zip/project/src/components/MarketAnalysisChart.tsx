import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { RxData } from '../types';

interface MarketComparisonChartProps {
  data: RxData[];
  type: 'TRx' | 'NBRx';
}

export const MarketComparisonChart: React.FC<MarketComparisonChartProps> = ({ data, type }) => {
  const processedData = data
    .map(entry => {
      const normalizedDate = entry.date.charAt(0).toUpperCase() + entry.date.slice(1);

      // Map data for each product
      return {
        date: normalizedDate,
        lumryz: Number(entry[`lumryz${type}Share`]) || 0,
        xywav: Number(entry[`xywav${type}Share`]) || 0,
        sodOxybate: Number(entry[`sodOxybate${type}Share`]) || 0,
        xyrem: Number(entry[`xyrem${type}Share`]) || 0,
      };
    })
    // Filter out entries with no data and duplicates
    .filter((d, index, self) => 
      (d.lumryz > 0 || d.xywav > 0 || d.sodOxybate > 0 || d.xyrem > 0) && 
      index === self.findIndex(t => t.date === d.date)
    )
    // Sort chronologically
    .sort((a, b) => {
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const [aMonth, aYear] = a.date.split(' ');
      const [bMonth, bYear] = b.date.split(' ');
      
      if (aYear !== bYear) {
        return Number(aYear) - Number(bYear);
      }
      return months.indexOf(aMonth) - months.indexOf(bMonth);
    });

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer>
        <LineChart data={processedData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2e2e2e" />
          <XAxis 
            dataKey="date" 
            stroke="#676767"
            tick={{ fill: '#676767' }}
            allowDuplicatedCategory={false}
          />
          <YAxis 
            domain={[0, 100]}
            stroke="#676767"
            tick={{ fill: '#676767' }}
            label={{ 
              value: 'Market Share (%)', 
              angle: -90, 
              position: 'insideLeft',
              style: { fill: '#676767' }
            }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#252525',
              border: '1px solid #2e2e2e',
              color: '#676767'
            }}
            formatter={(value: number, name: string) => [
              `${value.toFixed(1)}%`,
              name.toUpperCase()
            ]}
          />
          <Legend 
            wrapperStyle={{
              color: '#676767'
            }}
          />
          <Line 
            type="monotone" 
            dataKey="lumryz" 
            name="LUMRYZ" 
            stroke="#82ca9d" 
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
          />
          <Line 
            type="monotone" 
            dataKey="xywav" 
            name="XYWAV" 
            stroke="#8884d8" 
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
          />
          <Line 
            type="monotone" 
            dataKey="sodOxybate" 
            name="SOD-OXYBATE" 
            stroke="#ffc658" 
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
          />
          <Line 
            type="monotone" 
            dataKey="xyrem" 
            name="XYREM" 
            stroke="#ff8042" 
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};