import React from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { RxData } from '../types';

interface GPOPerformanceProps {
  data: RxData[];
  title: string;
  product: 'xywav' | 'sodOxybate' | 'xyrem';
}

export const GPOPerformance: React.FC<GPOPerformanceProps> = ({
  data,
  title,
  product
}) => {
  // Process TRx data
  const processedTRxData = data
    .map(entry => {
      if (!entry || !entry.date) return null;
      
      const normalizedDate = entry.date.charAt(0).toUpperCase() + entry.date.slice(1);
      
      // Calculate total volume for the bar chart
      const totalVolume = (
        (entry.xywavTRxVolume || 0) +
        (entry.lumryzTRxVolume || 0) +
        (entry.sodOxybateTRxVolume || 0) +
        (entry.xyremTRxVolume || 0)
      );

      return {
        date: normalizedDate,
        totalVolume,
        lumryzShare: Number(entry.lumryzTRxShare) || 0,
        xywavShare: Number(entry.xywavTRxShare) || 0,
        sodOxybateShare: Number(entry.sodOxybateTRxShare) || 0,
        xyremShare: Number(entry.xyremTRxShare) || 0
      };
    })
    .filter(d => d && d.totalVolume > 0)
    .sort((a, b) => {
      if (!a || !b || !a.date || !b.date) return 0;
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const [aMonth, aYear] = a.date.split(' ');
      const [bMonth, bYear] = b.date.split(' ');
      
      if (aYear !== bYear) {
        return Number(aYear) - Number(bYear);
      }
      return months.indexOf(aMonth) - months.indexOf(bMonth);
    });

  // Process NBRx data
  const processedNBRxData = data
    .map(entry => {
      if (!entry || !entry.date) return null;
      
      const normalizedDate = entry.date.charAt(0).toUpperCase() + entry.date.slice(1);
      
      // Calculate total volume for the bar chart
      const totalVolume = (
        (entry.xywavNBRxVolume || 0) +
        (entry.lumryzNBRxVolume || 0) +
        (entry.sodOxybateNBRxVolume || 0) +
        (entry.xyremNBRxVolume || 0)
      );

      return {
        date: normalizedDate,
        totalVolume,
        lumryzShare: Number(entry.lumryzNBRxShare) || 0,
        xywavShare: Number(entry.xywavNBRxShare) || 0,
        sodOxybateShare: Number(entry.sodOxybateNBRxShare) || 0,
        xyremShare: Number(entry.xyremNBRxShare) || 0
      };
    })
    .filter(d => d && d.totalVolume > 0)
    .sort((a, b) => {
      if (!a || !b || !a.date || !b.date) return 0;
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const [aMonth, aYear] = a.date.split(' ');
      const [bMonth, bYear] = b.date.split(' ');
      
      if (aYear !== bYear) {
        return Number(aYear) - Number(bYear);
      }
      return months.indexOf(aMonth) - months.indexOf(bMonth);
    });

  const renderChart = (data: any[], type: string) => (
    <div className="h-[400px] w-full">
      <ResponsiveContainer>
        <ComposedChart data={data}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2e2e2e" />
          <XAxis 
            dataKey="date" 
            stroke="#676767"
            tick={{ fill: '#676767' }}
          />
          <YAxis 
            yAxisId="left"
            domain={[0, 100]}
            stroke="#676767"
            tick={{ fill: '#676767' }}
            label={{ 
              value: 'Market Share (%)', 
              angle: -90, 
              position: 'insideLeft',
              style: { fill: '#676767' }
            }}
          />
          <YAxis 
            yAxisId="right" 
            orientation="right"
            stroke="#676767"
            tick={{ fill: '#676767' }}
            label={{ 
              value: 'Volume', 
              angle: 90, 
              position: 'insideRight',
              style: { fill: '#676767' }
            }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#252525',
              border: '1px solid #2e2e2e',
              color: '#676767'
            }}
            formatter={(value: number, name: string) => {
              if (name === 'Total Volume') {
                return [Math.round(value).toLocaleString(), name];
              } else {
                return [`${value.toFixed(1)}%`, name];
              }
            }}
          />
          <Legend />
          <Bar
            yAxisId="right"
            dataKey="totalVolume"
            name="Total Volume"
            fill="#8884d8"
            opacity={0.8}
          />
          <Line
            yAxisId="left"
            type="monotone"
            dataKey="lumryzShare"
            name="Lumryz Share"
            stroke="#82ca9d"
            strokeWidth={2}
            dot={{ r: 4 }}
          />
          <Line
            yAxisId="left"
            type="monotone"
            dataKey="xywavShare"
            name="Xywav Share"
            stroke="#ffc658"
            strokeWidth={2}
            dot={{ r: 4 }}
          />
          <Line
            yAxisId="left"
            type="monotone"
            dataKey="sodOxybateShare"
            name="Sod Oxybate Share"
            stroke="#ff7300"
            strokeWidth={2}
            dot={{ r: 4 }}
          />
          <Line
            yAxisId="left"
            type="monotone"
            dataKey="xyremShare"
            name="Xyrem Share"
            stroke="#0088fe"
            strokeWidth={2}
            dot={{ r: 4 }}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );

  return (
    <div className="space-y-8">
      <div className="bg-[#171717] p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-6 text-white">{title} - TRx Analysis</h2>
        {renderChart(processedTRxData, 'TRx')}
      </div>
      <div className="bg-[#171717] p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold mb-6 text-white">{title} - NBRx Analysis</h2>
        {renderChart(processedNBRxData, 'NBRx')}
      </div>
    </div>
  );
};