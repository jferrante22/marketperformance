import React, { useState, useEffect } from 'react';
import { clsx } from 'clsx';

interface DataTableProps {
  title: string;
  data: Record<string, any>[];
  columns: {
    key: string;
    header: string;
    type: 'text' | 'number';
    format?: (value: any) => string;
  }[];
  onDataChange: (newData: Record<string, any>[]) => void;
}

export const DataTable: React.FC<DataTableProps> = ({
  title,
  data,
  columns,
  onDataChange,
}) => {
  const [editingCell, setEditingCell] = useState<{ row: number; col: string } | null>(null);
  const [localData, setLocalData] = useState<Record<string, any>[]>(data);

  useEffect(() => {
    setLocalData(data);
  }, [data]);

  const handleCellEdit = (rowIndex: number, columnKey: string, value: string) => {
    const newData = [...localData];
    const column = columns.find(col => col.key === columnKey);
    
    let processedValue = value;
    if (column?.type === 'number') {
      if (value === '' || value === '.') {
        processedValue = null;
      } else if (/^\d*\.?\d*$/.test(value)) {
        const parsed = parseFloat(value);
        processedValue = isNaN(parsed) ? null : parsed;
      } else {
        return; // Invalid number input
      }
    }
    
    newData[rowIndex] = {
      ...newData[rowIndex],
      [columnKey]: processedValue,
    };
    setLocalData(newData);
    onDataChange(newData);
  };

  const addNewRow = () => {
    const newRow = columns.reduce((acc, col) => ({
      ...acc,
      [col.key]: null
    }), {});
    
    setLocalData([...localData, newRow]);
    onDataChange([...localData, newRow]);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium">{title}</h3>
        <button
          onClick={addNewRow}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
        >
          Add Row
        </button>
      </div>
      
      <div className="overflow-x-auto">
        <table className="min-w-full bg-white border border-gray-200">
          <thead>
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="px-4 py-2 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider border-b"
                >
                  {column.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {localData.map((row, rowIndex) => (
              <tr key={rowIndex} className={rowIndex % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                {columns.map((column) => (
                  <td
                    key={column.key}
                    className={clsx(
                      "px-4 py-2 text-sm text-gray-900 border-b",
                      "cursor-pointer hover:bg-gray-100"
                    )}
                    onClick={() => setEditingCell({ row: rowIndex, col: column.key })}
                  >
                    {editingCell?.row === rowIndex && editingCell?.col === column.key ? (
                      <input
                        type="text"
                        className="w-full p-1 border rounded"
                        value={row[column.key] || ''}
                        onChange={(e) => handleCellEdit(rowIndex, column.key, e.target.value)}
                        onBlur={() => setEditingCell(null)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            setEditingCell(null);
                          }
                        }}
                        autoFocus
                      />
                    ) : (
                      column.format ? column.format(row[column.key]) : (row[column.key] || '-')
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};