import React, { useState, useEffect } from 'react';
import { RxData } from '../types';
import { clsx } from 'clsx';

interface RxDataTableProps {
  data: RxData[];
  onDataChange: (newData: RxData[]) => void;
  rxType: 'TRx' | 'NBRx';
  product: 'zinc' | 'emisar' | 'ascent';
}

export const RxDataTable: React.FC<RxDataTableProps> = ({ data, onDataChange, rxType, product }) => {
  const [editingCell, setEditingCell] = useState<{ row: number; col: string } | null>(null);
  const [localData, setLocalData] = useState<RxData[]>(data);

  useEffect(() => {
    setLocalData(data);
  }, [data]);

  const products = ['lumryz', 'xywav', 'sodOxybate', 'xyrem'] as const;

  const parseInputValue = (value: string): number | null => {
    if (value === '') return null;
    const cleanValue = value.replace(/,/g, '');
    const parsed = parseFloat(cleanValue);
    return isNaN(parsed) ? null : parsed;
  };

  const handleCellEdit = (rowIndex: number, productKey: string, value: string) => {
    const newValue = parseInputValue(value);
    const volumeKey = `${productKey}${rxType}Volume` as keyof RxData;

    const newData = localData.map((item, index) => {
      if (index !== rowIndex) return item;

      const updatedItem = { ...item };
      updatedItem[volumeKey] = newValue;

      // Recalculate shares
      const totalVolume = products.reduce((sum, prod) => {
        const key = `${prod}${rxType}Volume` as keyof RxData;
        return sum + (Number(updatedItem[key]) || 0);
      }, 0);

      products.forEach(prod => {
        const shareKey = `${prod}${rxType}Share` as keyof RxData;
        const prodVolume = Number(updatedItem[`${prod}${rxType}Volume` as keyof RxData]) || 0;
        updatedItem[shareKey] = totalVolume > 0 ? (prodVolume / totalVolume) * 100 : 0;
      });

      return updatedItem;
    });

    setLocalData(newData);
    onDataChange(newData);
  };

  const addNewRow = () => {
    const newRow: RxData = {
      date: '',
      xywavTRxVolume: null,
      lumryzTRxVolume: null,
      sodOxybateTRxVolume: null,
      xyremTRxVolume: null,
      xywavTRxShare: 0,
      lumryzTRxShare: 0,
      sodOxybateTRxShare: 0,
      xyremTRxShare: 0,
      xywavNBRxVolume: null,
      lumryzNBRxVolume: null,
      sodOxybateNBRxVolume: null,
      xyremNBRxVolume: null,
      xywavNBRxShare: 0,
      lumryzNBRxShare: 0,
      sodOxybateNBRxShare: 0,
      xyremNBRxShare: 0
    };

    const newData = [...localData, { ...newRow, date: ' ' }];
    setLocalData(newData);
    onDataChange(newData);
  };

  const formatDisplayValue = (value: number | null): string => {
    if (value === null) return '';
    return value.toString();
  };

  return (
    <div className="overflow-x-auto">
      <div className="flex justify-between items-center mb-4">
        <button
          onClick={addNewRow}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
        >
          Add Row
        </button>
      </div>
      <table className="min-w-full bg-[#171717] border border-[#2e2e2e]">
        <thead>
          <tr>
            <th className="px-4 py-2 bg-[#252525] text-left text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e]">
              Month
            </th>
            {products.map(prod => (
              <th key={prod} className="px-4 py-2 text-right text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e]">
                {prod} Volume
              </th>
            ))}
            {products.map(prod => (
              <th key={`${prod}-share`} className="px-4 py-2 text-right text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e]">
                {prod} Share (%)
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {localData.map((row, rowIndex) => (
            <tr key={`row-${rowIndex}`} className={rowIndex % 2 === 0 ? 'bg-[#1e1e1e]' : 'bg-[#171717]'}>
              <td className="px-4 py-2 text-sm text-white border-b border-[#2e2e2e]">
                <input
                  type="text"
                  className="w-full bg-transparent border-none text-white"
                  value={row.date}
                  onChange={(e) => {
                    const newData = [...localData];
                    newData[rowIndex] = { ...newData[rowIndex], date: e.target.value };
                    setLocalData(newData);
                    onDataChange(newData);
                  }}
                />
              </td>
              {products.map(prod => {
                const volumeKey = `${prod}${rxType}Volume` as keyof RxData;
                return (
                  <td key={prod} className="px-4 py-2 text-right text-white border-b border-[#2e2e2e]">
                    <input
                      type="text"
                      className="w-full bg-transparent border-none text-right text-white"
                      value={formatDisplayValue(row[volumeKey])}
                      onChange={(e) => {
                        handleCellEdit(rowIndex, prod, e.target.value);
                      }}
                    />
                  </td>
                );
              })}
              {products.map(prod => {
                const shareKey = `${prod}${rxType}Share` as keyof RxData;
                return (
                  <td key={`${prod}-share`} className="px-4 py-2 text-right text-white border-b border-[#2e2e2e]">
                    {row[shareKey]?.toFixed(1)}%
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};