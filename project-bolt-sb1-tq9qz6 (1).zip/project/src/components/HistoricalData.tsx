import React from 'react';
import { LivesData, RxData } from '../types';
import { CoverageOverview } from './coverage/CoverageOverview';
import { CoverageChart } from './CoverageChart';
import { MarketComparisonChart } from './MarketAnalysisChart';
import { RxChart } from './RxChart';
import { GPOPerformance } from './GPOPerformance';

interface HistoricalDataProps {
  livesData: LivesData[];
  rxData: RxData[];
  zincData: RxData[];
  emisarData: RxData[];
  ascentData: RxData[];
}

export const HistoricalData: React.FC<HistoricalDataProps> = ({
  livesData,
  rxData,
  zincData,
  emisarData,
  ascentData
}) => {
  return (
    <div className="space-y-8">
      <div>
        <h2 className="text-xl font-semibold mb-6 text-white">Historical Coverage Data</h2>
        <div className="space-y-8">
          <CoverageOverview data={livesData} />
          <div className="bg-[#171717] p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-6 text-white">Commercial Lives Covered by Month Post Launch</h2>
            <CoverageChart data={livesData} type="commercial" />
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-6 text-white">Historical Market Performance</h2>
        <div className="space-y-8">
          <div className="bg-[#171717] p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-6 text-white">Market Share Comparison</h2>
            <MarketComparisonChart data={rxData} type="TRx" />
          </div>
          <div className="bg-[#171717] p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-6 text-white">Lumryz TRx Analysis</h2>
            <RxChart data={rxData} type="TRx" product="lumryz" />
          </div>
          <div className="bg-[#171717] p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-6 text-white">Lumryz NBRx Analysis</h2>
            <RxChart data={rxData} type="NBRx" product="lumryz" />
          </div>
        </div>
      </div>

      <div>
        <h2 className="text-xl font-semibold mb-6 text-white">Historical GPO Performance</h2>
        <div className="space-y-8">
          <GPOPerformance 
            data={zincData} 
            title="Zinc Performance"
            product="xywav"
          />
          <GPOPerformance 
            data={emisarData}
            title="Emisar Performance"
            product="sodOxybate"
          />
          <GPOPerformance 
            data={ascentData}
            title="Ascent Performance"
            product="xyrem"
          />
        </div>
      </div>
    </div>
  );
};