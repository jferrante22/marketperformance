import React, { useState, useEffect } from 'react';
import { clsx } from 'clsx';

interface DecimalDataTableProps {
  data: any[];
  onDataChange: (newData: any[]) => void;
  columns: {
    key: string;
    header: string;
    type: 'text' | 'decimal';
  }[];
  title: string;
}

export const DecimalDataTable: React.FC<DecimalDataTableProps> = ({
  data,
  onDataChange,
  columns,
  title
}) => {
  const [localData, setLocalData] = useState(data);
  const [editingCell, setEditingCell] = useState<{ row: number; col: string } | null>(null);

  useEffect(() => {
    setLocalData(data);
  }, [data]);

  const handleCellEdit = (rowIndex: number, field: string, value: string) => {
    const newData = [...localData];
    const column = columns.find((col) => col.key === field);

    if (column?.type === 'decimal') {
      // Allow decimal numbers and empty values
      if (value === '' || /^-?\d*\.?\d*$/.test(value)) {
        newData[rowIndex] = {
          ...newData[rowIndex],
          [field]: value // Keep raw input value during editing
        };
      }
    } else {
      newData[rowIndex] = {
        ...newData[rowIndex],
        [field]: value
      };
    }

    setLocalData(newData);
  };

  const handleBlur = (rowIndex: number, field: string) => {
    const newData = [...localData];
    const value = newData[rowIndex][field];
    const column = columns.find((col) => col.key === field);

    if (column?.type === 'decimal') {
      // Parse value on blur
      const parsedValue = value === '' || value === null ? null : parseFloat(value);
      newData[rowIndex] = {
        ...newData[rowIndex],
        [field]: parsedValue
      };
    }

    setLocalData(newData);
    onDataChange(newData);
  };

  const addNewRow = () => {
    // Initialize a new row with space in text fields and null in decimal fields
    const newRow = columns.reduce(
      (acc, col) => ({
        ...acc,
        [col.key]: col.type === 'text' ? ' ' : null
      }),
      {}
    );

    const newData = [...localData, newRow];
    console.log('Adding new row:', newRow);
    console.log('New data state:', newData);
    setLocalData(newData);
    onDataChange(newData);
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-medium text-white">{title}</h3>
        <button
          onClick={addNewRow}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
        >
          Add Row
        </button>
      </div>

      <div className="overflow-x-auto">
        <table className="min-w-full bg-[#171717] border border-[#2e2e2e]">
          <thead>
            <tr>
              {columns.map((column) => (
                <th
                  key={column.key}
                  className="px-4 py-2 bg-[#252525] text-left text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e]"
                >
                  {column.header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {localData.map((row, rowIndex) => (
              <tr
                key={rowIndex}
                className={rowIndex % 2 === 0 ? 'bg-[#1e1e1e]' : 'bg-[#171717]'}
              >
                {columns.map((column) => (
                  <td
                    key={column.key}
                    className={clsx(
                      'px-4 py-2 text-sm text-white border-b border-[#2e2e2e]',
                      'cursor-pointer hover:bg-[#2d2d2d]'
                    )}
                    onClick={() => setEditingCell({ row: rowIndex, col: column.key })}
                  >
                    {editingCell?.row === rowIndex && editingCell?.col === column.key ? (
                      <input
                        type="text"
                        className="w-full p-1 border rounded bg-[#1e1e1e] text-white border-[#2e2e2e]"
                        value={row[column.key] === null ? '' : row[column.key]}
                        onChange={(e) => handleCellEdit(rowIndex, column.key, e.target.value)}
                        onBlur={() => {
                          handleBlur(rowIndex, column.key);
                          setEditingCell(null);
                        }}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            handleBlur(rowIndex, column.key);
                            setEditingCell(null);
                          }
                        }}
                        autoFocus
                      />
                    ) : column.type === 'decimal' ? (
                      row[column.key] !== null ? parseFloat(row[column.key]).toFixed(2) : '-'
                    ) : (
                      row[column.key] || '-'
                    )}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};