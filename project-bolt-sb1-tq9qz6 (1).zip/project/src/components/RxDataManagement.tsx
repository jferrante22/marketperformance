import React, { useState, useEffect } from 'react';
import { RxData } from '../types';
import { RxDataTable } from './RxDataTable';

interface RxDataManagementProps {
  data: RxData[];
  onDataChange: (newData: RxData[]) => void;
}

export const RxDataManagement: React.FC<RxDataManagementProps> = ({ data, onDataChange }) => {
  const [localData, setLocalData] = useState<RxData[]>(data);

  useEffect(() => {
    setLocalData(data);
  }, [data]);

  const handleVolumeDataChange = (type: 'TRx' | 'NBRx') => (newData: RxData[]) => {
    console.log('Volume data change:', { type, newData });
    setLocalData(newData);
    onDataChange(newData);
  };

  return (
    <div className="bg-[#171717] p-6 rounded-lg shadow space-y-8">
      <div>
        <h3 className="text-lg font-medium mb-4 text-[#676767]">TRx Data</h3>
        <RxDataTable 
          data={localData}
          onDataChange={handleVolumeDataChange('TRx')}
          rxType="TRx"
          product="rx"
        />
      </div>
      <div>
        <h3 className="text-lg font-medium mb-4 text-[#676767]">NBRx Data</h3>
        <RxDataTable 
          data={localData}
          onDataChange={handleVolumeDataChange('NBRx')}
          rxType="NBRx"
          product="rx"
        />
      </div>
    </div>
  );
};