import React, { useState, useEffect } from 'react';

interface SimpleDataTableProps {
  data: any[];
  onDataChange: (newData: any[]) => void;
  title: string;
}

export const SimpleDataTable: React.FC<SimpleDataTableProps> = ({ data, onDataChange, title }) => {
  const [localData, setLocalData] = useState(data);
  const [editingCell, setEditingCell] = useState<{row: number, col: string} | null>(null);

  useEffect(() => {
    setLocalData(data);
  }, [data]);

  const handleCellEdit = (rowIndex: number, field: string, value: string) => {
    const newData = [...localData];
    newData[rowIndex] = {
      ...newData[rowIndex],
      [field]: value === '' ? null : Number(value)
    };
    setLocalData(newData);
    onDataChange(newData);
  };

  const addNewRow = () => {
    const newRow = {
      date: '',
      volume: null,
      share: null
    };
    const newData = [...localData, newRow];
    setLocalData(newData);
    onDataChange(newData);
  };

  return (
    <div className="bg-[#171717] p-6 rounded-lg">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium text-white">{title}</h3>
        <button
          onClick={addNewRow}
          className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
        >
          Add Row
        </button>
      </div>
      <table className="w-full">
        <thead>
          <tr>
            <th className="text-left p-2 text-gray-400">Month</th>
            <th className="text-right p-2 text-gray-400">Volume</th>
          </tr>
        </thead>
        <tbody>
          {localData.map((row, rowIndex) => (
            <tr key={rowIndex} className="border-t border-[#2e2e2e]">
              <td className="p-2">
                <input
                  type="text"
                  className="w-full bg-transparent text-white border border-transparent hover:border-gray-600 focus:border-blue-500 p-1 rounded"
                  value={row.date || ''}
                  onChange={(e) => handleCellEdit(rowIndex, 'date', e.target.value)}
                />
              </td>
              <td className="p-2">
                <input
                  type="text"
                  className="w-full bg-transparent text-white text-right border border-transparent hover:border-gray-600 focus:border-blue-500 p-1 rounded"
                  value={row.volume?.toString() || ''}
                  onChange={(e) => handleCellEdit(rowIndex, 'volume', e.target.value)}
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};