import React from 'react';
import { LivesData, RxData } from '../types';

interface DataFormProps {
  type: 'lives' | 'rx';
  onSubmit: (data: LivesData | RxData) => void;
}

export const DataForm: React.FC<DataFormProps> = ({ type, onSubmit }) => {
  const [formData, setFormData] = React.useState<any>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev: any) => ({
      ...prev,
      [name]: value === '' ? null : parseFloat(value),
    }));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {type === 'lives' ? (
        <>
          <div className="grid grid-cols-2 gap-4">
            <input
              type="text"
              name="month"
              placeholder="Month (M00-M24)"
              className="p-2 border rounded"
              onChange={(e) =>
                setFormData((prev: any) => ({
                  ...prev,
                  month: e.target.value,
                }))
              }
            />
            <input
              type="number"
              name="lumryzCommercial"
              placeholder="Lumryz Commercial %"
              className="p-2 border rounded"
              step="any" // Allows decimal values
              onChange={handleChange}
            />
            {/* Add other lives data inputs */}
          </div>
        </>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-4">
            <input
              type="date"
              name="date"
              className="p-2 border rounded"
              onChange={(e) =>
                setFormData((prev: any) => ({
                  ...prev,
                  date: e.target.value,
                }))
              }
            />
            <input
              type="number"
              name="lumryzTRxShare"
              placeholder="Lumryz TRx Share %"
              className="p-2 border rounded"
              step="any" // Allows decimal values
              onChange={handleChange}
            />
            {/* Add other Rx data inputs */}
          </div>
        </>
      )}
      <button
        type="submit"
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600"
      >
        Submit Data
      </button>
    </form>
  );
};
