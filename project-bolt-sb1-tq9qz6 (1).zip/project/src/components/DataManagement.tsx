import React from 'react';
import { RxData, LivesData } from '../types';

interface DataManagementProps {
  rxData: RxData[];
  livesData: LivesData[];
  zincData: RxData[];
  emisarData: RxData[];
  ascentData: RxData[];
  onRxDataChange: (data: RxData[]) => void;
  onLivesDataChange: (data: LivesData[]) => void;
  onZincDataChange: (data: RxData[]) => void;
  onEmisarDataChange: (data: RxData[]) => void;
  onAscentDataChange: (data: RxData[]) => void;
}

export const DataManagement: React.FC<DataManagementProps> = ({
  rxData,
  livesData,
  zincData,
  emisarData,
  ascentData,
  onRxDataChange,
  onLivesDataChange,
  onZincDataChange,
  onEmisarDataChange,
  onAscentDataChange,
}) => {
  const handleExportData = () => {
    const data = {
      rxData,
      livesData,
      zincData,
      emisarData,
      ascentData,
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'market-performance-data.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleImportData = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = JSON.parse(e.target?.result as string);
        if (data.rxData) onRxDataChange(data.rxData);
        if (data.livesData) onLivesDataChange(data.livesData);
        if (data.zincData) onZincDataChange(data.zincData);
        if (data.emisarData) onEmisarDataChange(data.emisarData);
        if (data.ascentData) onAscentDataChange(data.ascentData);
      } catch (error) {
        console.error('Error importing data:', error);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="flex gap-4 mb-6">
      <button
        onClick={handleExportData}
        className="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
      >
        Export Data
      </button>
      <label className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition-colors cursor-pointer">
        Import Data
        <input
          type="file"
          accept=".json"
          onChange={handleImportData}
          className="hidden"
        />
      </label>
    </div>
  );
};