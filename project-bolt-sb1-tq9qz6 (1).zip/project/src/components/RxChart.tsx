import React from 'react';
import { ComposedChart, Bar, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { RxData } from '../types';

interface RxChartProps {
  data: RxData[];
  type: 'TRx' | 'NBRx';
  product: 'xywav' | 'sodOxybate' | 'xyrem';
}

export const RxChart: React.FC<RxChartProps> = ({ data, type, product }) => {
  const processedData = data
    .map(entry => {
      const volumeKey = `${product}${type}Volume` as keyof RxData;
      const shareKey = `${product}${type}Share` as keyof RxData;
      
      // Normalize the date format
      const normalizedDate = entry.date.charAt(0).toUpperCase() + entry.date.slice(1);
      
      return {
        date: normalizedDate,
        volume: Number(entry[volumeKey]) || 0,
        share: Number(entry[shareKey]) || 0
      };
    })
    // Filter out zero values AND duplicate dates
    .filter((d, index, self) => 
      (d.volume > 0 || d.share > 0) && 
      index === self.findIndex(t => t.date === d.date)
    )
    // Sort by date to ensure consistent order
    .sort((a, b) => {
      const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
      const [aMonth, aYear] = a.date.split(' ');
      const [bMonth, bYear] = b.date.split(' ');
      
      if (aYear !== bYear) {
        return Number(aYear) - Number(bYear);
      }
      return months.indexOf(aMonth) - months.indexOf(bMonth);
    });

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer>
        <ComposedChart data={processedData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2e2e2e" />
          <XAxis 
            dataKey="date" 
            stroke="#676767"
            tick={{ fill: '#676767' }}
            allowDuplicatedCategory={false}
          />
          <YAxis 
            yAxisId="left"
            domain={[0, 100]}
            stroke="#676767"
            tick={{ fill: '#676767' }}
            label={{ 
              value: 'Market Share (%)', 
              angle: -90, 
              position: 'insideLeft',
              style: { fill: '#676767' }
            }}
          />
          <YAxis 
            yAxisId="right" 
            orientation="right"
            stroke="#676767"
            tick={{ fill: '#676767' }}
            label={{ 
              value: 'Volume', 
              angle: 90, 
              position: 'insideRight',
              style: { fill: '#676767' }
            }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#252525',
              border: '1px solid #2e2e2e',
              color: '#676767'
            }}
            formatter={(value: number, name: string) => [
              name === 'Market Share' ? `${value.toFixed(1)}%` : value.toLocaleString(),
              name
            ]}
          />
          <Legend />
          <Bar
            yAxisId="right"
            dataKey="volume"
            name="Volume"
            fill="#8884d8"
            opacity={0.8}
          />
          <Line
            yAxisId="left"
            type="monotone"
            dataKey="share"
            name="Market Share"
            stroke="#82ca9d"
            strokeWidth={2}
            dot={{ r: 4 }}
          />
        </ComposedChart>
      </ResponsiveContainer>
    </div>
  );
};