import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { LivesData } from '../types';

interface CoverageChartProps {
  data: LivesData[];
  type: 'commercial' | 'medicare';
}

export const CoverageChart: React.FC<CoverageChartProps> = ({ data, type }) => {
  const formatPercent = (value: number) => `${value.toFixed(1)}%`;

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer>
        <LineChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="month" />
          <YAxis tickFormatter={formatPercent} />
          <Tooltip formatter={formatPercent} />
          <Legend />
          <Line
            type="monotone"
            dataKey={`lumryz${type === 'commercial' ? 'Commercial' : 'Medicare'}`}
            name="Lumryz"
            stroke="#8884d8"
            strokeWidth={2}
          />
          <Line
            type="monotone"
            dataKey={`wakix${type === 'commercial' ? 'Commercial' : 'Medicare'}`}
            name="Wakix"
            stroke="#82ca9d"
            strokeWidth={2}
          />
          <Line
            type="monotone"
            dataKey={`xywav${type === 'commercial' ? 'Commercial' : 'Medicare'}`}
            name="Xywav"
            stroke="#ffc658"
            strokeWidth={2}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};