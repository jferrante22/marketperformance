import React, { useState, useEffect } from 'react';
import { RxData } from '../types';
import { clsx } from 'clsx';

interface RxShareTableProps {
  data: RxData[];
  rxType: 'TRx' | 'NBRx';
  onDataChange?: (newData: RxData[]) => void;
}

export const RxShareTable: React.FC<RxShareTableProps> = ({ data, rxType, onDataChange }) => {
  const [editingCell, setEditingCell] = useState<{ row: string; col: number } | null>(null);
  const [editingHeader, setEditingHeader] = useState<number | null>(null);
  const [localData, setLocalData] = useState<RxData[]>([]);
  const [months, setMonths] = useState<string[]>([]);

  useEffect(() => {
    if (data.length > 0) {
      setLocalData(data);
      setMonths(data.map(d => d.date));
    }
  }, [data]);

  const products = ['XYWAV', 'LUMRYZ', 'SOD-OXYBATE', 'XYREM'];

  const productKeyMap: Record<string, string> = {
    'XYWAV': 'xywav',
    'LUMRYZ': 'lumryz',
    'SOD-OXYBATE': 'sodOxybate',
    'XYREM': 'xyrem'
  };

  const handleCellEdit = (product: string, monthIndex: number, value: string) => {
    const newValue = value === '' ? null : parseFloat(value);
    const newData = [...localData];
    
    if (!newData[monthIndex]) {
      newData[monthIndex] = {
        date: months[monthIndex],
      } as RxData;
    }
    
    const productKey = productKeyMap[product];
    const key = `${productKey}${rxType}Share` as keyof RxData;
    
    console.log('Saving share data:', {
      product,
      productKey,
      rxType,
      key,
      value: newValue
    });

    newData[monthIndex] = {
      ...newData[monthIndex],
      [key]: newValue,
    };

    setLocalData(newData);
    onDataChange?.(newData.filter(item => item.date));
  };

  const handleHeaderEdit = (monthIndex: number, value: string) => {
    const newMonths = [...months];
    newMonths[monthIndex] = value;
    setMonths(newMonths);
    
    const newData = [...localData];
    if (!newData[monthIndex]) {
      newData[monthIndex] = {} as RxData;
    }
    newData[monthIndex].date = value;
    
    setLocalData(newData);
    onDataChange?.(newData.filter(item => item.date));
  };

  const addNewMonth = () => {
    setMonths([...months, '']);
    setLocalData([...localData, {} as RxData]);
    setEditingHeader(months.length);
  };

  return (
    <div className="overflow-x-auto mt-8">
      <div className="flex justify-between items-center mb-4">
        <h3 className="text-lg font-medium text-[#676767]">Market Share (%)</h3>
        <button
          onClick={addNewMonth}
          className="bg-[#f7b91c] text-black px-4 py-2 rounded hover:bg-[#e5aa19] transition-colors"
        >
          Add Month
        </button>
      </div>
      <table className="min-w-full bg-[#171717] border border-[#2e2e2e]">
        <thead>
          <tr>
            <th className="px-4 py-2 bg-[#252525] text-left text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e]">
              ALL GPOs
            </th>
            {months.map((month, i) => (
              <th 
                key={i} 
                className="px-4 py-2 bg-[#252525] text-left text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e] cursor-pointer hover:bg-[#2d2d2d]"
                onClick={() => setEditingHeader(i)}
              >
                {editingHeader === i ? (
                  <input
                    type="text"
                    className="w-full p-1 border rounded text-xs uppercase bg-[#1e1e1e] text-white border-[#2e2e2e]"
                    value={month || ''}
                    onChange={(e) => handleHeaderEdit(i, e.target.value)}
                    onBlur={() => setEditingHeader(null)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setEditingHeader(null);
                      }
                    }}
                    autoFocus
                  />
                ) : (
                  month || 'Click to edit'
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {products.map((product, rowIndex) => (
            <tr key={product} className={rowIndex % 2 === 0 ? 'bg-[#1e1e1e]' : 'bg-[#171717]'}>
              <td className="px-4 py-2 text-sm font-medium text-white border-b border-[#2e2e2e]">
                {product}
              </td>
              {months.map((_, colIndex) => (
                <td
                  key={colIndex}
                  className={clsx(
                    "px-4 py-2 text-sm text-right text-[#676767] border-b border-[#2e2e2e]",
                    "cursor-pointer hover:bg-[#2d2d2d]"
                  )}
                  onClick={() => setEditingCell({ row: product, col: colIndex })}
                >
                  {editingCell?.row === product && editingCell?.col === colIndex ? (
                    <input
                      type="number"
                      step="0.1"
                      className="w-full text-right p-1 border rounded bg-[#1e1e1e] text-white border-[#2e2e2e]"
                      value={localData[colIndex]?.[`${productKeyMap[product]}${rxType}Share` as keyof RxData] || ''}
                      onChange={(e) => handleCellEdit(product, colIndex, e.target.value)}
                      onBlur={() => setEditingCell(null)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          setEditingCell(null);
                        }
                      }}
                      autoFocus
                    />
                  ) : (
                    (localData[colIndex]?.[`${productKeyMap[product]}${rxType}Share` as keyof RxData]?.toFixed(1) + '%') || '-'
                  )}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};