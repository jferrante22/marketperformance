import React from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { LivesData } from '../../types';

interface CoveragePercentageChartProps {
  data: LivesData[];
}

export const CoveragePercentageChart: React.FC<CoveragePercentageChartProps> = ({ data }) => {
  const processedData = data.map(entry => ({
    month: entry.month,
    commercial: entry.lumryzCommercial || 0,
    medicare: entry.lumryzMedicare || 0,
    total: ((entry.lumryzCommercial || 0) + (entry.lumryzMedicare || 0)) / 2
  }));

  return (
    <div className="h-[400px] w-full">
      <ResponsiveContainer>
        <LineChart data={processedData}>
          <CartesianGrid strokeDasharray="3 3" stroke="#2e2e2e" />
          <XAxis 
            dataKey="month" 
            stroke="#676767"
            tick={{ fill: '#676767' }}
          />
          <YAxis 
            domain={[0, 100]}
            stroke="#676767"
            tick={{ fill: '#676767' }}
            label={{ 
              value: 'Coverage (%)', 
              angle: -90, 
              position: 'insideLeft',
              style: { fill: '#676767' }
            }}
          />
          <Tooltip 
            contentStyle={{ 
              backgroundColor: '#252525',
              border: '1px solid #2e2e2e',
              color: '#676767'
            }}
            formatter={(value: number) => [`${value.toFixed(1)}%`]}
          />
          <Legend 
            wrapperStyle={{
              color: '#676767'
            }}
          />
          <Line 
            type="monotone" 
            dataKey="commercial" 
            name="Commercial" 
            stroke="#3b82f6" 
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
          />
          <Line 
            type="monotone" 
            dataKey="medicare" 
            name="Medicare" 
            stroke="#22c55e" 
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
          />
          <Line 
            type="monotone" 
            dataKey="total" 
            name="Total Coverage" 
            stroke="#f59e0b" 
            strokeWidth={2}
            dot={{ r: 4 }}
            activeDot={{ r: 6 }}
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};