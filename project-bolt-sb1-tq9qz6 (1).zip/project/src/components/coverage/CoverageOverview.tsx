import React from 'react';
import { LivesData } from '../../types';

interface CoverageOverviewProps {
  data: LivesData[];
}

export const CoverageOverview: React.FC<CoverageOverviewProps> = ({ data }) => {
  // Get the latest data point
  const latestData = data[data.length - 1];

  const totalLives = 240.7; // Total lives in millions
  const coveredLives = 211.3; // Covered lives in millions
  const coveragePercentage = 88; // Total coverage percentage

  const commercialStats = {
    lives: '168.5M of 187.2M',
    percentage: 90,
    formularies: 187
  };

  const medicareStats = {
    lives: '42.8M of 53.5M',
    percentage: 80,
    formularies: 312
  };

  return (
    <div className="bg-[#171717] p-6 rounded-lg shadow">
      <div className="flex justify-between items-start mb-6">
        <div>
          <h2 className="text-xl font-semibold text-white">National Coverage Overview</h2>
          <p className="text-gray-400 text-sm">Coverage statistics across all channels</p>
        </div>
        <div className="text-right">
          <span className="text-4xl font-bold text-blue-500">{coveragePercentage}%</span>
          <p className="text-gray-400 text-sm">Total Coverage</p>
        </div>
      </div>

      <div className="w-full bg-gray-700 rounded-full h-2 mb-4">
        <div 
          className="bg-blue-500 h-2 rounded-full" 
          style={{ width: `${coveragePercentage}%` }}
        />
      </div>

      <p className="text-gray-400 text-sm mb-8">
        {coveredLives}M of {totalLives}M total lives covered
      </p>

      <div className="grid grid-cols-2 gap-8">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-6 h-6 bg-blue-100 rounded-lg flex items-center justify-center">
              <span className="text-blue-500 text-lg">📊</span>
            </div>
            <div className="flex justify-between items-center w-full">
              <span className="text-white font-medium">Commercial</span>
              <span className="text-2xl font-bold text-blue-500">{commercialStats.percentage}%</span>
            </div>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
            <div 
              className="bg-blue-500 h-2 rounded-full" 
              style={{ width: `${commercialStats.percentage}%` }}
            />
          </div>
          <div className="flex justify-between text-sm text-gray-400">
            <span>{commercialStats.lives}</span>
            <span>{commercialStats.formularies} formularies</span>
          </div>
        </div>

        <div>
          <div className="flex items-center gap-2 mb-2">
            <div className="w-6 h-6 bg-purple-100 rounded-lg flex items-center justify-center">
              <span className="text-purple-500 text-lg">📊</span>
            </div>
            <div className="flex justify-between items-center w-full">
              <span className="text-white font-medium">Medicare</span>
              <span className="text-2xl font-bold text-purple-500">{medicareStats.percentage}%</span>
            </div>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
            <div 
              className="bg-purple-500 h-2 rounded-full" 
              style={{ width: `${medicareStats.percentage}%` }}
            />
          </div>
          <div className="flex justify-between text-sm text-gray-400">
            <span>{medicareStats.lives}</span>
            <span>{medicareStats.formularies} formularies</span>
          </div>
        </div>
      </div>

      <p className="text-gray-400 text-xs mt-4">* Data sourced from formulary coverage analysis as of April 2024</p>
    </div>
  );
};