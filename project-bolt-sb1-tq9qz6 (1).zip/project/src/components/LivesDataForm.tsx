import React, { useState } from 'react';
import { LivesData } from '../types';

interface LivesDataFormProps {
  onSubmit: (data: LivesData) => void;
}

export const LivesDataForm: React.FC<LivesDataFormProps> = ({ onSubmit }) => {
  const [formData, setFormData] = useState<Partial<LivesData>>({});

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (formData.month) {
      onSubmit({
        month: formData.month,
        lumryzCommercial: formData.lumryzCommercial || null,
        wakixCommercial: formData.wakixCommercial || null,
        xywavCommercial: formData.xywavCommercial || null,
        lumryzMedicare: formData.lumryzMedicare || null,
        wakixMedicare: formData.wakixMedicare || null,
        xywavMedicare: formData.xywavMedicare || null,
      });
      setFormData({});
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    if (name === 'month' || value === '' || /^\d*\.?\d*$/.test(value)) {
      setFormData(prev => ({
        ...prev,
        [name]: name === 'month' ? value : 
                value === '' ? null : 
                /^\d*\.?\d*$/.test(value) ? parseFloat(value) || null : prev[name],
      }));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-1">
          Post-Approval Month
        </label>
        <input
          type="text"
          name="month"
          value={formData.month || ''}
          placeholder="M00"
          className="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500"
          onChange={handleChange}
        />
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h4 className="font-medium mb-2">Commercial Coverage</h4>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Wakix %
              </label>
              <input
                type="text"
                name="wakixCommercial"
                value={formData.wakixCommercial?.toString() || ''}
                className="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500"
                onChange={handleChange}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Xywav %
              </label>
              <input
                type="text"
                name="xywavCommercial"
                value={formData.xywavCommercial?.toString() || ''}
                className="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500"
                onChange={handleChange}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Lumryz %
              </label>
              <input
                type="text"
                name="lumryzCommercial"
                value={formData.lumryzCommercial?.toString() || ''}
                className="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500"
                onChange={handleChange}
              />
            </div>
          </div>
        </div>

        <div>
          <h4 className="font-medium mb-2">Medicare Coverage</h4>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Wakix %
              </label>
              <input
                type="text"
                name="wakixMedicare"
                value={formData.wakixMedicare?.toString() || ''}
                className="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500"
                onChange={handleChange}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Xywav %
              </label>
              <input
                type="text"
                name="xywavMedicare"
                value={formData.xywavMedicare?.toString() || ''}
                className="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500"
                onChange={handleChange}
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Lumryz %
              </label>
              <input
                type="text"
                name="lumryzMedicare"
                value={formData.lumryzMedicare?.toString() || ''}
                className="w-full p-2 border rounded focus:ring-blue-500 focus:border-blue-500"
                onChange={handleChange}
              />
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          type="submit"
          className="bg-blue-500 text-white px-6 py-2 rounded hover:bg-blue-600 transition-colors"
        >
          Add Data
        </button>
      </div>
    </form>
  );
};