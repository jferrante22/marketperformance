import React, { useState, useEffect } from 'react';
import { LivesData } from '../types';
import { DecimalDataTable } from './DecimalDataTable';

interface LivesDataTableProps {
  data: LivesData[];
  onDataChange?: (newData: LivesData[]) => void;
}

export const LivesDataTable: React.FC<LivesDataTableProps> = ({ data, onDataChange }) => {
  const [localData, setLocalData] = useState<LivesData[]>(data);

  useEffect(() => {
    setLocalData(data);
  }, [data]);

  const handleDataChange = (newData: any[]) => {
    // Keep rows that have any non-null value or a space in month
    const processedData = newData.filter(item => 
      item.month === ' ' || Object.values(item).some(val => val !== null && val !== '')
    );
    onDataChange?.(processedData);
  };

  const commercialColumns = [
    { key: 'month', header: 'Post-Approval Month', type: 'text' as const },
    { key: 'wakixCommercial', header: 'Wakix', type: 'decimal' as const },
    { key: 'xywavCommercial', header: 'Xywav', type: 'decimal' as const },
    { key: 'lumryzCommercial', header: 'Lumryz', type: 'decimal' as const },
  ];

  const medicareColumns = [
    { key: 'month', header: 'Post-Approval Month', type: 'text' as const },
    { key: 'wakixMedicare', header: 'Wakix', type: 'decimal' as const },
    { key: 'xywavMedicare', header: 'Xywav', type: 'decimal' as const },
    { key: 'lumryzMedicare', header: 'Lumryz', type: 'decimal' as const },
  ];

  return (
    <div className="space-y-8">
      <DecimalDataTable
        title="Commercial Coverage (%)"
        data={localData}
        columns={commercialColumns}
        onDataChange={handleDataChange}
      />
      
      <DecimalDataTable
        title="Medicare Coverage (%)"
        data={localData}
        columns={medicareColumns}
        onDataChange={handleDataChange}
      />
    </div>
  );
};