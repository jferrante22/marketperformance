import React, { useState, useEffect } from 'react';

interface EditableCellProps {
  value: number | null;
  onChange: (value: number | null) => void;
  type?: 'volume' | 'share';
}

export const EditableCell: React.FC<EditableCellProps> = ({ value, onChange, type = 'volume' }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [inputValue, setInputValue] = useState('');

  useEffect(() => {
    setInputValue(value?.toString() || '');
  }, [value]);

  const handleBlur = () => {
    setIsEditing(false);
    const parsed = inputValue === '' ? null : parseFloat(inputValue);
    if (parsed !== value) {
      onChange(parsed);
    }
  };

  const formatValue = (val: number | null) => {
    if (val === null || val === undefined) return '-';
    return type === 'share' ? `${val.toFixed(1)}%` : val.toLocaleString();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleBlur();
    } else if (e.key === 'Escape') {
      setIsEditing(false);
      setInputValue(value?.toString() || '');
    }
  };

  return (
    <div className="min-h-[28px]">
      {isEditing ? (
        <input
          type="text"
          className="w-full text-right p-1 border rounded bg-[#1e1e1e] text-white border-[#2e2e2e]"
          value={inputValue}
          onChange={(e) => setInputValue(e.target.value)}
          onBlur={handleBlur}
          onKeyDown={handleKeyDown}
          autoFocus
        />
      ) : (
        <div
          className="cursor-pointer hover:bg-[#2d2d2d] h-full w-full flex items-center justify-end"
          onClick={() => setIsEditing(true)}
        >
          {formatValue(value)}
        </div>
      )}
    </div>
  );
};