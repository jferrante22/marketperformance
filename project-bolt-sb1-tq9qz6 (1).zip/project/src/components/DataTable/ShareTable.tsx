import React from 'react';
import { RxData } from '../../types';

interface ShareTableProps {
  data: RxData[];
  months: string[];
  products: string[];
  productKeyMap: Record<string, string>;
  type: 'TRx' | 'NBRx';
}

export const ShareTable: React.FC<ShareTableProps> = ({
  data,
  months,
  products,
  productKeyMap,
  type,
}) => {
  return (
    <div>
      <h3 className="text-lg font-medium mb-4 text-white">Market Share (%) - Auto-calculated</h3>
      <table className="min-w-full bg-[#171717] border border-[#2e2e2e]">
        <thead>
          <tr>
            <th className="px-4 py-2 bg-[#252525] text-left text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e]">
              ALL GPOs
            </th>
            {months.map((month, i) => (
              <th 
                key={i}
                className="px-4 py-2 bg-[#252525] text-left text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e]"
              >
                {month}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {products.map((product, rowIndex) => (
            <tr key={product} className={rowIndex % 2 === 0 ? 'bg-[#1e1e1e]' : 'bg-[#171717]'}>
              <td className="px-4 py-2 text-sm font-medium text-white border-b border-[#2e2e2e]">
                {product}
              </td>
              {months.map((_, colIndex) => {
                const shareKey = `${productKeyMap[product]}${type}Share` as keyof RxData;
                const share = data[colIndex]?.[shareKey] as number;
                return (
                  <td
                    key={colIndex}
                    className="px-4 py-2 text-sm text-right text-[#676767] border-b border-[#2e2e2e]"
                  >
                    {share?.toFixed(1)}%
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};