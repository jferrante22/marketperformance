import React, { useState } from 'react';
import { RxData } from '../../types';
import { clsx } from 'clsx';

interface VolumeTableProps {
  data: RxData[];
  months: string[];
  products: string[];
  productKeyMap: Record<string, string>;
  type: 'TRx' | 'NBRx';
  onCellChange: (product: string, monthIndex: number, value: number | null) => void;
  onHeaderChange: (monthIndex: number, value: string) => void;
}

export const VolumeTable: React.FC<VolumeTableProps> = ({
  data,
  months,
  products,
  productKeyMap,
  type,
  onCellChange,
  onHeaderChange,
}) => {
  const [editingCell, setEditingCell] = useState<{ row: number; col: number } | null>(null);
  const [editingHeader, setEditingHeader] = useState<number | null>(null);

  const handleCellEdit = (product: string, monthIndex: number, value: string) => {
    const newValue = value === '' ? null : parseFloat(value);
    onCellChange(product, monthIndex, newValue);
    setEditingCell(null);
  };

  return (
    <div>
      <h3 className="text-lg font-medium mb-4 text-white">Volume Data</h3>
      <table className="min-w-full bg-[#171717] border border-[#2e2e2e]">
        <thead>
          <tr>
            <th className="px-4 py-2 bg-[#252525] text-left text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e]">
              ALL GPOs
            </th>
            {months.map((month, i) => (
              <th 
                key={i}
                className="px-4 py-2 bg-[#252525] text-left text-xs font-medium text-[#676767] uppercase tracking-wider border-b border-[#2e2e2e]"
                onClick={() => setEditingHeader(i)}
              >
                {editingHeader === i ? (
                  <input
                    type="text"
                    className="w-full p-1 border rounded text-xs uppercase bg-[#1e1e1e] text-white border-[#2e2e2e]"
                    value={month}
                    onChange={(e) => onHeaderChange(i, e.target.value)}
                    onBlur={() => setEditingHeader(null)}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        setEditingHeader(null);
                      }
                    }}
                    autoFocus
                  />
                ) : (
                  month
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {products.map((product, rowIndex) => (
            <tr key={product} className={rowIndex % 2 === 0 ? 'bg-[#1e1e1e]' : 'bg-[#171717]'}>
              <td className="px-4 py-2 text-sm font-medium text-white border-b border-[#2e2e2e]">
                {product}
              </td>
              {months.map((_, colIndex) => {
                const volumeKey = `${productKeyMap[product]}${type}Volume` as keyof RxData;
                const isEditing = editingCell?.row === rowIndex && editingCell?.col === colIndex;
                
                return (
                  <td
                    key={colIndex}
                    className={clsx(
                      "px-4 py-2 text-sm text-right text-[#676767] border-b border-[#2e2e2e]",
                      "cursor-pointer hover:bg-[#2d2d2d]"
                    )}
                    onClick={() => setEditingCell({ row: rowIndex, col: colIndex })}
                  >
                    {isEditing ? (
                      <input
                        type="text"
                        className="w-full text-right p-1 border rounded bg-[#1e1e1e] text-white border-[#2e2e2e]"
                        value={data[colIndex]?.[volumeKey]?.toString() || ''}
                        onChange={(e) => handleCellEdit(product, colIndex, e.target.value)}
                        onBlur={() => setEditingCell(null)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            setEditingCell(null);
                          }
                        }}
                        autoFocus
                      />
                    ) : (
                      <div className="min-h-[28px]">
                        {data[colIndex]?.[volumeKey]?.toLocaleString() || '-'}
                      </div>
                    )}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};