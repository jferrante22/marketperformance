import React, { useState } from 'react';

interface EditableHeaderProps {
  value: string;
  onChange: (value: string) => void;
}

export const EditableHeader: React.FC<EditableHeaderProps> = ({ value, onChange }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [inputValue, setInputValue] = useState(value);

  const handleBlur = () => {
    setIsEditing(false);
    onChange(inputValue);
  };

  return isEditing ? (
    <input
      type="text"
      className="w-full p-1 border rounded text-xs uppercase bg-[#1e1e1e] text-white border-[#2e2e2e]"
      value={inputValue}
      onChange={(e) => setInputValue(e.target.value)}
      onBlur={handleBlur}
      onKeyDown={(e) => {
        if (e.key === 'Enter') handleBlur();
      }}
      autoFocus
    />
  ) : (
    <div
      className="cursor-pointer hover:bg-[#2d2d2d]"
      onClick={() => setIsEditing(true)}
    >
      {value}
    </div>
  );
};