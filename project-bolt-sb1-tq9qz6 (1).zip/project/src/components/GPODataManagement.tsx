import React, { useState, useEffect } from 'react';
import { RxDataTable } from './RxDataTable';
import { RxData } from '../types';

interface GPODataManagementProps {
  initialData: RxData[];
  gpoName: 'zinc' | 'emisar' | 'ascent';
  onDataChange: (newData: RxData[]) => void;
}

export const GPODataManagement: React.FC<GPODataManagementProps> = ({ 
  initialData = [], // Provide default empty array
  gpoName,
  onDataChange 
}) => {
  const [data, setData] = useState<RxData[]>(initialData);

  useEffect(() => {
    // Ensure we always have an array, even if empty
    setData(initialData || []);
  }, [initialData]);

  useEffect(() => {
    console.log('GPODataManagement data updated:', {
      gpoName,
      dataLength: data?.length || 0,
      data
    });
  }, [data, gpoName]);

  const handleVolumeDataChange = (type: 'TRx' | 'NBRx') => (newData: RxData[]) => {
    console.log('Volume data change:', { 
      type, 
      gpoName,
      newData 
    });
    // Ensure we're not setting undefined
    const validData = newData || [];
    setData(validData);
    onDataChange(validData);
  };

  // Safely capitalize the GPO name
  const capitalizedGpoName = gpoName ? 
    gpoName.charAt(0).toUpperCase() + gpoName.slice(1) : 
    'GPO';

  return (
    <div className="bg-[#171717] p-6 rounded-lg shadow space-y-8">
      <h2 className="text-xl font-semibold text-white">
        {capitalizedGpoName} Performance Data
      </h2>
      
      <div>
        <h3 className="text-lg font-medium mb-4 text-[#676767]">TRx Analysis</h3>
        <RxDataTable 
          data={data || []}
          onDataChange={handleVolumeDataChange('TRx')}
          rxType="TRx"
          gpoName={gpoName}
        />
      </div>

      <div>
        <h3 className="text-lg font-medium mb-4 text-[#676767]">NBRx Analysis</h3>
        <RxDataTable 
          data={data || []}
          onDataChange={handleVolumeDataChange('NBRx')}
          rxType="NBRx"
          gpoName={gpoName}
        />
      </div>
    </div>
  );
};