import React from 'react';

interface ErrorMessageProps {
  error: Error;
}

export const ErrorMessage: React.FC<ErrorMessageProps> = ({ error }) => (
  <div className="min-h-screen bg-[#1e1e1e] flex items-center justify-center">
    <div className="bg-[#171717] p-6 rounded-lg shadow-lg max-w-md w-full">
      <h2 className="text-xl font-semibold text-red-500 mb-4">Error Loading Data</h2>
      <p className="text-white mb-4">{error.message}</p>
      <p className="text-gray-400 text-sm mb-4">
        Please check your internet connection and try again.
      </p>
      <button 
        onClick={() => window.location.reload()} 
        className="mt-4 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition-colors"
      >
        Retry Loading Data
      </button>
    </div>
  </div>
);