import React from 'react';

export const LoadingSpinner: React.FC = () => (
  <div className="min-h-screen bg-[#1e1e1e] flex items-center justify-center">
    <div className="animate-spin rounded-full h-32 w-32 border-t-2 border-b-2 border-blue-500"></div>
  </div>
);